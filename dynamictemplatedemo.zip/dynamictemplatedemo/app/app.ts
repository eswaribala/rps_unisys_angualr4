//our root app component
import { Component, ViewContainerRef, ViewChild } from '@angular/core'
import {DialogComponent } from './app.dialogcomponent'
import {DialogAnchorDirective} from './app.dialoganchorcomponent'
import { Service } from './service'


@Component({
  selector: 'my-app',
  template: `
    <div>
      <h2>Main Component {{name}}</h2>
       
      <button (click)="onClick()">Add Template</button>  
        
        
    </div>
    <div dialogAnchor></div>
    <div class="open-button" (click)='openDialogBox()'>Open dialog box</div>  
  `,
    styles: [`
        :host {
            display: flex;
            justify-content: center;
        }
        .open-button {
            padding: 5px;
            border: 2px solid red;
            cursor: pointer;
            margin-left: 2%;
        }
        [dialogAnchor] {
            display: none;
        }
    `],
    entryComponents: [DialogComponent]
})
export class App {
  name = 'from Angular'
    @ViewChild(DialogAnchorDirective) dialogAnchor: DialogAnchorDirective;

    openDialogBox() {
        this.dialogAnchor.createDialog(DialogComponent);
    }
  constructor(private service: Service, private viewContainerRef: ViewContainerRef) {

  }

  onClick()
  {
      this.service.setRootViewContainerRef(this.viewContainerRef)
      this.service.addDynamicComponent()
  }
  radioclick()
  {

  }
}

