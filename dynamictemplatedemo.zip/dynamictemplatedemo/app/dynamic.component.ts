import { Component } from '@angular/core'

@Component({
  selector: 'dynamic-component',
  template: `
    <h2>I'm dynamically attached</h2>
  `
})
export class DynamicComponent { }
