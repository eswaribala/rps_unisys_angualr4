import {BrowserModule} from "@angular/platform-browser";
import {NgModule} from '@angular/core';
import {App} from "./app";
import {DynamicComponent} from "./dynamic.component";
import {DialogComponent} from "./app.dialogcomponent";
import{DialogAnchorDirective} from "./app.dialoganchorcomponent";
import {Service} from "./service";

@NgModule({
    imports: [ BrowserModule ],
    declarations: [
        App,
        DynamicComponent,
        DialogComponent, DialogAnchorDirective
    ],
    providers: [ Service ],
    entryComponents: [ DynamicComponent ],
    bootstrap: [ App ]
})
export class AppModule{

}

