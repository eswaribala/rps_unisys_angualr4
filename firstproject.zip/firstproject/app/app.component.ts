import {Component} from "@angular/core";


@Component({
    selector:'test-tag',
    template:`<p>
        Ready to go with Angular 4....
        
    </p>`
})

export class AppComponent{

}