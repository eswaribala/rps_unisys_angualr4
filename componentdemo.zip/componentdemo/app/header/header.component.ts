import {Component,Input} from "@angular/core";
import {Header} from './header'

@Component({
    selector:'header-tag',
    templateUrl:'./app/header/header.component.html',
    styleUrls:['./app/header/header.component.css']
})

export class HeaderComponent{

    private header:Header;
    @Input() titleInfo:string;
    constructor()
    {
      this.header=new Header("./app/assets/unisys.jpg",
          this.titleInfo,
          ["Home","Product","Contact Us", "Clients"]);

    }


}