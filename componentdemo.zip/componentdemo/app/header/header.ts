export class Header
{
    private logo:string;
    private title:string;
    private menu:string[];
    constructor(logo:string,title:string,menu:string[])
    {
        this.logo=logo;
        this.title=title;
        this.menu=menu;
    }

    get Logo():string
    {
        return this.logo;
    }
    get Title():string
    {
        return this.title;
    }
    get Menu():string[]
    {
        return this.menu;
    }
}