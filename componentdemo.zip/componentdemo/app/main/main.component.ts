import {Component} from "@angular/core";


@Component({
    selector:'main-tag',
    templateUrl:'./app/main/main.component.html'

})

export class MainComponent{

    private title:string="Unisys India";


}