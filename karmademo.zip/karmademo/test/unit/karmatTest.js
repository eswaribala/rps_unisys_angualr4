/**
 * Created by BALASUBRAMANIAM on 05-04-2017.
 */
describe('when testing karma', function (){
    it('should report a successful test', function (){
        expect(true).toBeTruthy();
    });
});