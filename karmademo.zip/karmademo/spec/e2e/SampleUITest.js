/**
 * Created by BALASUBRAMANIAM on 05-04-2017.
 */
describe('',function(){
    beforeEach(function(){
        browser.get('http://localhost:63342/Expressjs/KarmaProject/index.html');
        var commentInput = $('input');
        commentInput.sendKeys("Testing Protractor framework");

        var submitButton = element(by.buttonText('Submit')).click();
        browser.driver.sleep(5);
    });
    it('Should then add the comment',function(){
        var comments = element.all(by.repeater('comment in comments')).first();
        expect(comments.getText()).toBe('Testing Protractor framework like 0');
    })
    describe('When I like a comment',function(){
        var firstComment = null;

        beforeEach(function(){
            firstComment = element.all(by.repeater('comment in comments')).first();
            var likeButton = firstComment.element(by.buttonText('like'));
            likeButton.click();
        })

        it('Should increase the number of likes to one',function(){
            var commentLikes = firstComment.element(by.binding('comment.likes'));
            expect(commentLikes.getText()).toBe('1');
        })
    })



});
