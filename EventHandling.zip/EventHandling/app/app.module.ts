import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { FriendsComponent } from './contacts/friends.component';
import {FriendDetailComponent} from './contact-details/friend-detail.component'

@NgModule({
  declarations: [
    AppComponent,
    FriendsComponent,
      FriendDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

