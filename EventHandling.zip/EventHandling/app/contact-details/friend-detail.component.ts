import { Component, OnInit, Input } from '@angular/core';
import { Friend } from '../friend';

@Component({
  selector: 'app-friend-detail',
  templateUrl: './app/contact-details/friend-detail.component.html',
  styleUrls: ['./app/contact-details/friend-detail.component.css']
})
export class FriendDetailComponent implements OnInit {
  @Input() friend: Friend;

  constructor() { }

  ngOnInit() {
  }

}
