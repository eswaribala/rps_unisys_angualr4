import { Component, OnInit } from '@angular/core';
import { Friend } from '../friend';
import { FRIENDS } from '../mock-friends';

@Component({
  selector: 'app-friends',
  templateUrl: './app/contacts/friends.component.html',
  styleUrls: ['./app/contacts/friends.component.css']
})
export class FriendsComponent implements OnInit {

 friends = FRIENDS;

  selectedFriend: Friend;


  constructor() { }

  ngOnInit() {
  }

  onSelect(friend: Friend): void {
    this.selectedFriend = friend;
  }
}

