export class Friend {
  id: number;
  name: string;
}

