import { Friend } from './friend';

export const FRIENDS: Friend[] = [
  { id: 1001, name: 'Mr. Nikhil' },
  { id: 1002, name: 'Namrata' },
  { id: 1003, name: 'Bharthi' },
  { id: 1004, name: 'Christy' },
  { id: 1005, name: 'Manasa' },
  { id: 1006, name: 'Raghav' },
  { id: 1007, name: 'Devi' },
  { id: 1008, name: 'Dr Sachin' },
  { id: 1009, name: 'Manisha' },
  { id: 1010, name: 'Tamil' }
];

