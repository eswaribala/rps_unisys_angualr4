import {Component} from "@angular/core";
import {Customer} from './app.customer'

@Component({
    selector:'test-tag',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']
})

export class AppComponent{

    private title:string;
    private customerArr:Customer[];
    private customerObj;

    constructor()
    {
        this.title="Customer List"
        this.customerArr=[new Customer(495694,"Anoop","5/5/1980"),
            new Customer(495694,"Jayanth","5/12/1990"),
            new Customer(495694,"Roopa","27/4/2010"),
            new Customer(495694,"Meena","14/5/2001"),
            new Customer(495694,"Vishal","15/5/1997")]

        this.customerObj=this.customerArr[0];
    }


}