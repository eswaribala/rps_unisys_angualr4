export class Customer{

    private  customerId:number;
    private customerName:string;
    private dob:string;
    constructor(id:number,cname:string,dob:string)
    {
        this.customerId=id;
        this.customerName=cname;
        this.dob=dob;
    }

    get CustomerId():number{
        return this.customerId;
    }

    get CustomerName():string
    {
        return this.customerName;
    }

    get DOB():string{
        return this.dob;
    }

}