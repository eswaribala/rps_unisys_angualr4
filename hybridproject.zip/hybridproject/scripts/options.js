/**
 * Created by BALASUBRAMANIAM on 17-03-2016.
 */


formmodule.constant('types', ['Users','Albums','Comments','Posts']);

formmodule.controller('DataServicesController',['$scope','types','DataFactory',function($scope,types,DataFactory)
{
    $scope.options=types;
    $scope.type='';
    $scope.models = {};
    $scope.typechange=function()
    {
        console.log($scope.type);
        DataFactory.findService($scope.type).then(function(info)
        {
            $scope.servicedata=info;
           console.log(info);
        });


    }

}]);


datamodule=angular.module('DataModule',['ServiceApp']);
datamodule.factory('DataFactory',['DataService',function(DataService)
{
    var serviceInstance={};

    serviceInstance.findService=function(type)
    {
       serviceobj = DataService.getData(type);
        return serviceobj;
    };
    return serviceInstance;

}]);
