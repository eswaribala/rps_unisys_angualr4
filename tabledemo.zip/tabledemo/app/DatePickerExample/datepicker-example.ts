import {Component} from '@angular/core';

/**
 * @title Datepicker API
 */
@Component({
    selector: 'datepicker-api-example',
    templateUrl: './app/DatePickerExample/datepicker-api-example.html',
    styleUrls: ['./app/DatePickerExample/datepicker-api-example.css'],
})
export class DatepickerApiExample {
}
